"""Fresh cut replay ablations; exact graph equality, not just minimum score.

One Slurm task handles one reaction/direction/policy. Every cut graph is saved.
Matching, symmetry, scoring, persistence and audit encoding are timed separately.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import shlex
import shutil
import subprocess
import sys
import time

import numpy as np
from rxn_core.domain import AAMProblem, MolecularEndpoint
from rxn_core.aam import cut_seed
from rxn_core.alignment.branch import _generate_seed_orders, find_islands
from rxn_core.alignment.sweep import cut_sweep_items
from rxn_core.artifacts import write_graph_checkpoint
from rxn_core.cut_replay import CutReplay
from rxn_core.frag import build_graph
from rxn_core.matcher import _nauty_orbits
from rxn_core.search_graph import AAMSearchGraph
from rxn_core.search_symmetry import finalize_graph_symmetry
from compare_elementary_outputs import event_counts

SOURCE=Path('/project/yunhengzou/coordinate_alignment/aam_benchmarks/elementary140_tol1_20260909')
POLICIES=('independent','shared_fresh','shared_whole','shared_checkpoint')


def save(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,indent=2)+'\n')


def task(args):
    spec=json.loads((args.run/'tasks.json').read_text())[args.slot]
    index,direction,policy,seeds=(spec[k] for k in ('index','direction','policy','seeds'))
    folder=args.run/f"results/{index}/{direction}/{policy}"
    folder.mkdir(parents=True,exist_ok=False)
    raw=json.loads((SOURCE/f'inputs/{index}/input.json').read_text())
    original=AAMProblem(*(MolecularEndpoint(**raw[k]) for k in ('reactant','product')))
    problem=AAMProblem(original.product,original.reactant) if direction=='P_to_R' else original
    timings={}
    def measure(label,fn):
        cpu=time.process_time();wall=time.perf_counter()
        value=fn()
        row=timings.setdefault(label,dict(cpu=0.,wall=0.))
        row['cpu']+=time.process_time()-cpu;row['wall']+=time.perf_counter()-wall
        return value
    def prepare():
        r=build_graph(problem.reactant.elements,problem.reactant.wbo,bond_cut=.2)
        p=build_graph(problem.product.elements,problem.product.wbo,bond_cut=.2)
        po=_nauty_orbits(p,wbo_tol=1.)
        replay=CutReplay(r,p,po,checkpoints=policy=='shared_checkpoint') if policy in ('shared_whole','shared_checkpoint') else None
        return r,p,po,replay,_generate_seed_orders(r,seeds,rng_seed=42)
    source,target,p_orbits,replay,shared_orders=measure('setup',prepare)
    cuts=cut_sweep_items(problem.reactant.wbo,.2)
    records=[];witnesses=set()
    for ordinal,cut in enumerate(cuts):
        def search():
            view=replay.for_cut(cut) if replay else None
            r=view.source if view else source.copy()
            if view is None:r.remove_edges_from(cut)
            ro=_nauty_orbits(r,wbo_tol=1.)
            orders=(_generate_seed_orders(r,seeds,rng_seed=cut_seed(cut))
                    if policy=='independent' else shared_orders)
            graphs=[find_islands(r,target,order,graph_floor=.2,iso_tol=1.,max_branches=100,
                        r_orbits=ro,p_orbits=p_orbits,cuts=cut,growth_replay=view) for order in orders]
            return AAMSearchGraph.combine(graphs)
        graph=measure('search',search)
        graph,groups=measure('symmetry',lambda:finalize_graph_symmetry(graph,target,iso_tolerance=1.))
        def score():
            vectors=[]
            for terminal in graph.terminals:
                m=dict(graph.states[terminal].mapping)
                if len(m)!=original.atom_count:continue
                if direction=='P_to_R':m={b:a for a,b in m.items()}
                vectors.append(tuple(m[i] for i in range(original.atom_count)))
            witnesses.update(vectors)
            counts=event_counts(original.reactant.wbo,original.product.wbo,vectors) if vectors else []
            return min((int(sum(row)) for row in counts),default=None)
        best=measure('score',score)
        digest=measure('audit_encoding',lambda:hashlib.sha256(
            json.dumps(graph.to_record(copy=False),sort_keys=True,separators=(',',':')).encode()).hexdigest())
        measure('persistence',lambda:write_graph_checkpoint(graph,folder/f'cut_{ordinal:04d}.pkl.gz'))
        records.append(dict(cut=cut,digest=digest,best=best,terminals=len(graph.terminals),
                            capped=graph.capped,states=len(graph.states),groups=groups))
        save(folder/'progress.json',dict(completed=len(records),total=len(cuts),timings=timings))
    counts=event_counts(original.reactant.wbo,original.product.wbo,sorted(witnesses)) if witnesses else []
    save(folder/'witnesses.json',dict(mappings=sorted(witnesses),events=[list(map(int,row)) for row in counts]))
    save(folder/'summary.json',dict(**spec,name=raw['name'],cuts=records,timings=timings,
        best=min((r['best'] for r in records if r['best'] is not None),default=None),
        replay=None if replay is None else replay.stats(),witnesses=len(witnesses),
        peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        host=os.uname().nodename,pid=os.getpid(),settings=dict(branch_cap=100,match_tolerance=1.,
        event_tolerance=.5,bond_floor=.2,explicit_hydrogen=True,cache_bytes=64*1024*1024),
        timing_scope='Fresh process per reaction/direction/policy. Queue/import/input loading excluded. Persistence and audit encoding separated; no subtraction from summed worker time.'))


def prepare(args):
    tasks=[dict(index=i,direction=d,policy=p,seeds=args.seeds)
           for i in args.indices for d in ('R_to_P','P_to_R') for p in args.policies]
    save(args.run/'tasks.json',tasks)
    (args.run/'status').mkdir(exist_ok=True)
    root=Path(__file__).resolve().parents[1]
    shutil.copytree(root/'src',args.run/'engine/src',ignore=shutil.ignore_patterns('__pycache__'))
    shutil.copytree(root/'bench',args.run/'engine/bench',ignore=shutil.ignore_patterns('__pycache__'))
    save(args.run/'manifest.json',dict(parent_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
        source=str(SOURCE),tasks=len(tasks),seeds=args.seeds,policies=args.policies,
        native_sha256=hashlib.sha256(next((args.run/'engine/src/rxn_core').glob('_engine*.so')).read_bytes()).hexdigest()))
    print(len(tasks),'tasks prepared')


def submit(args):
    tasks=json.loads((args.run/'tasks.json').read_text())
    cmd=['env','OMP_NUM_THREADS=1','OPENBLAS_NUM_THREADS=1','MKL_NUM_THREADS=1',
         'PYTHONHASHSEED=0','RXN_CORE_NATIVE=1',
         f'PYTHONPATH={args.run}/engine/src:{args.run}/engine/bench',
         'timeout','--kill-after=5s','300',sys.executable,str(args.run/'engine/bench/cut_replay_pilot.py'),
         'task','--run',str(args.run),'--slot']
    options=['sbatch','--parsable','--partition=cpunodes,cpunodes_nia',
             '--exclude=bosque5,bosque6,bosque8,bosque10','--cpus-per-task=1','--mem=4G',
             '--time=00:10:00',f'--array=0-{len(tasks)-1}%96','--job-name=cut_replay',
             f'--output={args.run}/status/%A_%a.out','--wrap',shlex.join(cmd)+' "$SLURM_ARRAY_TASK_ID"']
    job=subprocess.check_output(options,text=True).strip()
    save(args.run/'submission.json',dict(job=job,command=options));print(job)


def report(args):
    tasks=json.loads((args.run/'tasks.json').read_text());rows=[];missing=[]
    for slot,t in enumerate(tasks):
        path=args.run/f"results/{t['index']}/{t['direction']}/{t['policy']}/summary.json"
        if path.exists():rows.append(json.loads(path.read_text()))
        else:missing.append(slot)
    totals={}
    for p in POLICIES:
        chosen=[r for r in rows if r['policy']==p]
        if not chosen:continue
        totals[p]=dict(tasks=len(chosen),timings={k:sum(r['timings'][k]['cpu'] for r in chosen)
            for k in chosen[0]['timings']},best=[(r['index'],r['direction'],r['best']) for r in chosen],
            peak_rss_mib=max(r['peak_rss_kib'] for r in chosen)/1024,
            replay={k:sum(r['replay'][k] for r in chosen) for k in
                    ('calls','full_hits','prefix_hits','logical_extensions','reused_extensions',
                     'logical_certificates','reused_certificates','evictions')} if chosen[0]['replay'] else None)
    base={(r['index'],r['direction']):r for r in rows if r['policy']=='shared_fresh'}
    mismatches=[];checked=0
    for row in rows:
        if row['policy'] not in ('shared_whole','shared_checkpoint'):continue
        reference=base.get((row['index'],row['direction']))
        if reference is None:continue
        for a,b in zip(reference['cuts'],row['cuts'],strict=True):
            checked+=1
            if a['digest']!=b['digest']:mismatches.append((row['index'],row['direction'],row['policy'],a['cut']))
    summary=dict(completed=len(rows),missing=missing,totals=totals,
                 exact_cut_graph_comparisons=checked,mismatches=mismatches)
    save(args.run/'summary.json',summary);print(json.dumps(summary,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command',choices=('prepare','submit','task','report'))
    p.add_argument('--run',type=Path,required=True);p.add_argument('--slot',type=int)
    p.add_argument('--indices',type=int,nargs='+',default=[0,4,59,64,114,123,135,136])
    p.add_argument('--seeds',type=int,default=1)
    p.add_argument('--policies',nargs='+',choices=POLICIES,default=list(POLICIES))
    a=p.parse_args();globals()[a.command](a)
