"""One-factor holdout rerun: frozen original AAM engine, matching tolerance 1.0."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
from types import SimpleNamespace


def save(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def prepare(args):
    source = args.source
    args.run.mkdir(parents=True, exist_ok=False)
    for folder in ('engine', 'inputs', 'slap_xyz'):
        shutil.copytree(source / folder, args.run / folder,
                        ignore=shutil.ignore_patterns('__pycache__'))
    (args.run / 'status').mkdir()
    for name in ('manifest.json', 'inputs/manifest.json'):
        original = json.loads((source / name).read_text())
        assert original['config']['iso_tolerance'] == .5
        original['config']['iso_tolerance'] = 1.0
        if name == 'manifest.json':
            original['protocols']['aam'] = 'Frozen original engine; explicit H; both directions; seed 10; cap 100; matching tolerance 1.0; event threshold 0.5; sweep cut.'
            original['tolerance_ab'] = dict(source=str(source), changed_search_settings={'iso_tolerance': [.5, 1.0]},
                native_slap='Byte-identical saved outputs reused; its search does not use our matching tolerance.',
                cap123='No substitution with old cap-200 run; all new cases start at cap 100.')
        save(args.run / name, original)
    for path in (source / 'inputs').glob('*/input.json'):
        assert path.read_bytes() == (args.run / 'inputs' / path.parent.name / path.name).read_bytes()
    # Preserve exact original executable sources, not a newly modified core.
    for path in (source / 'engine/src').rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts:
            assert path.read_bytes() == (args.run / 'engine/src' / path.relative_to(source / 'engine/src')).read_bytes()
    shutil.copy2(__file__, args.run / 'campaign.py')
    for folder in ('comparison', 'overlap'):
        (args.run / folder).mkdir()
    print(args.run)


def submit(args):
    assert not (args.run / 'jobs.json').exists()
    engine = args.run / 'engine'
    env = ['env', 'OMP_NUM_THREADS=1', 'OPENBLAS_NUM_THREADS=1', 'MKL_NUM_THREADS=1',
           'PYTHONHASHSEED=0', 'RXN_CORE_NATIVE=1', f'PYTHONPATH={engine}/src:{engine}/bench', 'CUDA_VISIBLE_DEVICES=']
    command = [*env, sys.executable, str(engine / 'bench/elementary_feasibility.py'),
               'worker', '--run', str(args.run), '--method', 'aam', '--slot']
    options = ['sbatch', '--parsable', '--partition=cpunodes', '--nodes=1', '--cpus-per-task=16',
               '--mem=32G', '--time=00:10:00', '--array=0-279%32', '--job-name=elem_tol1',
               f'--output={args.run}/status/aam_%A_%a.out', '--wrap', shlex.join(command) + ' "$SLURM_ARRAY_TASK_ID"']
    if args.exclude: options.insert(2, '--exclude=' + args.exclude)
    job = subprocess.check_output(options, text=True).strip()
    save(args.run / 'jobs.json', [dict(method='aam', job=job, command=options)])
    print(job)


def analyze(args):
    from compare_elementary_outputs import compare, refine
    from elementary_family_overlap import analyze as overlap
    for direction in ('R_to_P', 'P_to_R'):
        result = json.loads((args.run / 'directions' / str(args.index) / direction / 'feasibility.json').read_text())
        if not result['valid_full_terminal_mappings']:
            raise RuntimeError(f'Case {args.index} {direction}: no full mapping; investigate before comparing')
    job = SimpleNamespace(index=args.index, source=args.run, cap200=args.run, run=args.run / 'comparison')
    compare(job)
    refine(job)
    overlap(SimpleNamespace(index=args.index, comparison=args.run / 'comparison', run=args.run / 'overlap'))


def status(args):
    rows = [json.loads(p.read_text()) for p in (args.run / 'status').glob('aam_*.json')]
    print(json.dumps(dict(completed=len(rows), exits=dict(Counter(str(r['exit']) for r in rows)),
                         failed=[r for r in rows if r['exit'] != 0],
                         analyzed=len(list((args.run / 'comparison').glob('*.refined.json')))), indent=2))


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('command', choices=('prepare', 'submit', 'analyze', 'status'))
    p.add_argument('--run', type=Path, required=True)
    p.add_argument('--source', type=Path, default=Path('/project/yunhengzou/coordinate_alignment/aam_benchmarks/elementary140_feasibility_20260908'))
    p.add_argument('--exclude'); p.add_argument('--index', type=int)
    args = p.parse_args(); globals()[args.command](args)
